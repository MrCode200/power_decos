import pytest
import io

from time import sleep

from decorators import get_time, init_logger

init_logger(True)

@get_time
def test_get_run_time(capfd):
    sleep(1.5)
    capture = capfd.readouterr()

