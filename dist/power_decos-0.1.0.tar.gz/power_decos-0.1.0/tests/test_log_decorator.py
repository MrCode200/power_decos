from decorators import log
from time import sleep


@log()
def test_log1():
    return 'hello'


@log()
def test_log2():
    raise Exception("This is a test for the @log decorator")


if __name__ == "__main__":
    #test_get_run_time()
    #test_retry()
    a = test_log1()
    #sleep(1)
    test_log2()
    #sleep(1)